raio = 0
pi = 3.14
area = 0

raio = float(input("Informe o raio: "))
area = (pi*(raio)**2)
print("O valor da area e igual a: {0} ".format(area))