raio = 0
pi = 3.14159
area = 0

raio = float(input("Informe o raio: "))
area = (pi*(raio)**2)
print("O valor da area e igual a: {0} ".format(area))

 ##   cod = int(input("informe o codigo"))
   ## qtd = int(input("informe a quantidade"))
   # uni = float(input("informe o valor unitario"))
   # valorTotal1 = (qtd * uni);##

   ## cod = int(input("informe o codigo"))
  ##  qtd = int(input("informe a quantidade"))
   ## uni = float(input("informe o valor unitario"))
    ##valorTotal2 = (qtd * uni);

   ## valorTotal = valorTotal1 + valorTotal2;


   ## print(" o valor a pagar é {0}".format(valorTotal))##