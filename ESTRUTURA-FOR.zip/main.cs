using System;

class MainClass {
  public static void Main (string[] args) {
    float soma = 0;
    float media = 0;

    for(int i=0;i<5;i++){
        Console.WriteLine("Digite a primeira nota: " + i + ":");
        float nota = 0;
        float.TryParse(Console.ReadLine(),out nota);
        soma += nota;
    }
    media = soma / 5;
    Console.WriteLine("A sua media é igual a: "+ media);
    Console.ReadKey();
  }
}