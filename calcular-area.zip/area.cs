using System;
namespace calcular{
    class area{
       
        public int l1;
        public int l2;
        public float pi;
        public float alt;
    
        public void l1(int lado1){
            l1 = lado1;
        }
        public void l2(int lado2){
            l2 = lado2;
        }
        public void pi(float P){
            pi = P;
        }
        public void alt(float altura){
            alt = altura;
        }
        public static int Area1(){
            Area1 = lado1 * lado2;
            return Area1;
        }
        public static int Area2(){
            Area2 = (lado2 *alt) /2;
            return Area2;
        }
        public static int  Area3(){
            Area3 = ((2* pi)*(r* r));
            return Area3;  
        }
    }
} 