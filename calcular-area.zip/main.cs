using System;

class MainClass {
    public static void Main (string[] args) {
        area A = new area();

        Console.WriteLine (area.Area1(8, 6));
        Console.WriteLine (area.Area2(6, 15.4));
        Console.WriteLine (area.Area3(3.14, 5));
    }
}