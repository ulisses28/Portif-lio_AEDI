using System;

class MainClass {
  public static void Main (string[] args) {
    

      Console.WriteLine("entre com um numero: ");
      int num1 = int.Parse(Console.ReadLine());

      Console.WriteLine("entre com um numero: ");
      int num2 = int.Parse(Console.ReadLine());

      double soma = num1 + num2;

    Console.WriteLine("A soma é igual a: "+ soma);
    Console.WriteLine ("Hello World");
  }
}