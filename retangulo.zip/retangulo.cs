using System;
// Classe Retangulo: Crie uma classe que modele um retangulo:
//A-LadoA, LadoB (ou Comprimento e Largura, ou Base e Altura, a escolher)
//B- Métodos: Mudar valor dos lados, Retornar valor dos lados, calcular Área e calcular Perímetro;
//C-Crie um programa que utilize esta classe. Ele deve pedir ao usuário que informe as medidades de um local. Depois, deve criar um objeto com as medidas e calcular a quantidade de pisos e de rodapés necessárias para o local.
namespace retangulo{

    class retangulo{
        private int LadoH;
        private int LadoB;
        public double calcularA;
        public double calcularP;
        
    }
    public retangulo(){
        ladoH = 15;
        ladoB = 7;
        calcularA = 0;
        calcularP = 0 ;
    }

    public int getladoH(){
        LadoA = 15;
        return ladoH;
    }

    public int getladoB(){
        ladoB = 7;
        return ladoB;
    }

    public int getmudarladoH(){
        return ladoH;
    }

    public void setmudarladoH(int lh){
        ladoH = lh;
    }

    public int getmudarladoB(){
        return ladoB;
    }

    public void setmudarladoB(int lb){
        ladoB = lb;
    }

    public double getcalcularA(){
        calcularA = lh * lb;
        return calcularA;
    }

    public double getcalcularP(){
        calcularP = 2 * (lh * lb);
        return calcularP;
    }
  }
}