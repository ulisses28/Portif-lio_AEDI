using System;

namespace retangulo{
    class MainClass{
        public static void Main(string[] args){

            retangulo minhaArea1 = new retangulo();
            retangulo minhaArea2 = new retangulo();
            retangulo result3 = new retangulo();
            retangulo result4 = new retangulo();

            Console.WriteLine(minhaArea1);
            Console.WriteLine(minhaArea2);
            Console.WriteLine(result3);
            Console.WriteLine(result4);

        }
    }
}