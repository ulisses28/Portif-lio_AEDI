using System;

class MainClass {
  public static void Main (string[] args) {
      string[] a = new string[3];
      a[0] = "ulisses";
      a[1] = "giselle";
      a[2] = "Rebeca";

      foreach(string nome in a)
      {
          Console.WriteLine(nome);
      }

    Console.ReadLine();
  }
}