using System;

class Pessoa{
    public string Nome;
    private int Idade;
    protected string Cor;

    public void Nome(string N){
        Nome = N;
    }
    public void Idade(int I){
        Idade = I;
    }
    public void Cor(string C){
        Cor = C;
    }
    public string Falar(){
        return Falar;
    }
    public float Crescer(){
        Crescer = (idade/2)*10;
        return Crescer;
    }
}