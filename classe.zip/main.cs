using System;

class MainClass {
  public static void Main (string[] args) {
      Pessoa = pessoa = new Pessoa();

      Pessoa.Nome("Ulisses");
      pessoa.getIdade(29);
      pessoa.getCor("Pardo");
      pessoa.Falar("Oi boa tarde,podemos conversar");
      pessoa.Crescer();
      
      Console.WriteLine ("Meu nome é {0} tenho {1} anos", pessoa.Nome, Pessoa.Idade);
      Console.WriteLine ("Sua cor é {0} ", pessoa.Cor);
      Console.WriteLine(Pessoa.Falar);
      Console.WriteLine("Ele cresceu: "+ pessoa.Crescer)
    }
}