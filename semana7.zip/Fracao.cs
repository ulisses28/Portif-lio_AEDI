using System;

namespace MathFracao{
    class Fracao{
        private double num;
        private double den;
    }
        public Fracao(double n, double d){
            num = (n);
            den = (d)
        }
        // metodo
        public bool Igual(Fracao f){
            //if(this.num == f.num && this.den == f.den){
            }
            if(this.num/this.den == f.num/f.den){
                return true;
            }
            return false;
        }
        public bool Diferente(Fracao f){
            if(this.Igual(f) == true){
                return false;
            }
            return true;
        }
    
}