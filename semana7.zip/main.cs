using System;

class MainClass {
  public static void Main (string[] args) {
      Fracao a = new Fracao(1,2);,
      Fracao b = new Fracao(2,4);
    Console.WriteLine (a.Igual(b));
  }
}