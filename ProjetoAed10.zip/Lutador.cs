using system;
using system.Collections.Generic;
using system.linq;
using system.text;
using system.threading.tasks;

namespace classeLutador{

    public class Lutador{
        // atributes 
        private string _Nome();
        private string _Nacionalidade();
        private int _Idade();
        private float _Altura();
        private float _Peso();
        private string _Categoria();
        private int _Vitorias();
        private int _Derrotas();
        private int _Empates();

        // metodos
        public string _Apresentar;
        public string _Status;
        public int _ganharLuta;
        public int _empatarLuta;
        public int _perderLuta;
        public int _validarSaude;
        }
        
        private void setNome(string no){
            this.Nome = no;
            }
        public string getNome{
            return Nome;
        }
            
        public string Nacionalidade(){
            set{
                this.Nacionalidade = na;

            }
            get{
                return Nacionalidade;
            }
                
        }
        public int Idade{
            set{
                this.idade = id;
            }
            get{
                return idade;
            }
        }
        public float Altura{
            set{
                this.Altura = no;
            }
            get{
                return Altura;
            }
            
        }
        public  float Peso{                                                                                   
        public v int Vitorias(){
            set
            {
                this.Vitorias = vt;
            }
            get
            {
                return Vitorias;
            }
        }
        public int Derrotas(){
            set
            {
                this.Derrotas = dr;
            }
            get
            {
                return Derrotas;
            }
        }
        public  int Empates(){
            set{
            
                this.Empates = no;
            }
            get
            
                return Empates;
            }

        }
        public int ganharLuta(){
            this.setVitorias(this.getVitorias() += 1);

        }
        public int perderLuta(){
            this.setDerrotas(this.getDerrotas() += 1);
        }
        public int empatarLuta(){
            this.setEmpates(this.getEmpates() += 1);
        }
        public bool validarSaude(){
            Console.WriteLine("Saúde ()Boa ou ()Ruim "); this.getvalidarSaude();
            if(this.validarSaude == Boa){
                return true ("Candidato apto para luta");
            }
            else{
                if(this.validarSaude == Ruim){
                    return false ("Luta cancelada!");
                }
            }

        }
        //  Metodo que recebe os valores dos atributos do lutador
        public string Apresentar(){
            Console.WriteLine("========================================");
            Console.WriteLine("Chegou a hora da luta! Apresentamos o lutador", + this._());
            Console.WriteLine("Lutador ", this._());
            Console.WriteLine("De Nacionalidade ", this.getNacionalidade());
            Console.WriteLine("Sua Idade é ",this.getIdade(), "Anos");
            Console.WriteLine(this.getAltura(), "Metros");
            Console.WriteLine("Peso", this.getPeso(), "Kg");
            Console.WriteLine("Ganhou ", this.getVitorias());
            Console.WriteLine("Perdeu ", this.getDerrotas());
            Console.WriteLine("Empatou ", this.getEmpates());
            Console.WriteLine("saúde", this.getvalidarSaude());

        }
        // Metodo que exibirá na tela o status do lutador com algumas caracteristicas
        public string Status(){
            Console.WriteLine(this._(),"é um peso ", + this.getCategoria);
            Console.WriteLine(this.getVitorias(), "Vitorias");
            Console.WriteLine(this.getDerrotas(), "Derrotas");
            Console.WriteLine(this.getEmpates(), "Empatou");
            Console.WriteLine("saúde", this.getvalidarSaude());
        }

    }
}
