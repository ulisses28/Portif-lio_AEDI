using System;

class MainClass {
  public static void Main (string[] args) {
    //lutador [] = new Lutador(0,1,2,3,4,5);

    Lutador l1 = new lutador("Pretty Boy","França",31,1.75f,68.9f,11,3,1,Boa);
    l1.apresentar();
    //lutador[0] = new lutador("Pretty Boy","França",31,1.75,68.9,11,3,1,Boa);
    //lutador[0].apresentar();
    //lutador[0].Status();
    
    lutador l2 = new lutador("Putscript","Brasil",29,1.68f,57.8f,14,2,3,Boa);
    //lutador[1] = new lutador("Putscript","Brasil",29,1.68,57.8,14,2,3,Boa);
    //lutador[0].apresentar();
    //lutador[0].Status();

    lutador l3 = new lutador("Snapshadow", "EUA", 35, 1.65f, 80.9f, 12, 2, 1, "Boa");
    //lutador[2] = new lutador("Snapshadow","EUA",35,1.65,80.9,12,2,1,Boa);
    //lutador[0].apresentar();
    //lutador[0].Status();

    lutador l4 = new lutador("Dead Code","Australia",28,1.93f,81.6f,13,0,2,Boa);
    //lutador[3] = new lutador("Dead Code","Australia",28,1.93,81.6,13,0,2,Boa);
    //lutador[0].apresentar();
    //lutador[0].Status();

    lutador l5 = new lutador("SpaceDown","Inglaterra",31,1.73f,70.3f,7,1,9,Boa);
    //lutador[4] = new lutador("SpaceDown","Inglaterra",31,1.73,70.3,7,1,9,Boa);
    //lutador[0].apresentar();
    //lutador[0].Status();

    lutador l6 = new lutador("Chadow Mac","Russia",42,1.65f,78.7f,21,5,1,"Boa");
    //lutador[5] = new lutador("Chadow Mac","Russia",42,1.65,78.7,21,5,1,Boa);
    //lutador[0].apresentar();
    //lutador[0].Status();
  }
}