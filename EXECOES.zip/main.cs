using System;

class MainClass {
  public static void Main (string[] args) {
      try{
          int y = 0;
          int x = 0;
          for(i =0;i<2;i++){
              Console.WriteLine("Entre com 2 numeros: ");
              int x = int.Parse(Console.ReadLine());
              int y = int.Parse(Console.ReadLine());
          }
          result = (2 * y)/x;
          caso2 = x/y;
          if(x == 0){
              catch(Exception)
              {
                  trow = new Excecao("Um numero não pode ser dividido por zero!");
                }
          }
          else{
              return true;
          }
          Console.WriteLine("O resultado de result é: "+ result);
          Console.WriteLine("O resultado do caso2: "+ caso2);
    }
}