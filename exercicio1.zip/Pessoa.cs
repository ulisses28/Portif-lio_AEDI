using System;

class Pessoa{
    public string NomeC;
    public int IdadeA;
    public string NomeD;
    public int IdadeB;
    }
