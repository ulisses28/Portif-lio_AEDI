using System;

class MainClass {
  public static void Main (string[] args) {
      
      Pessoa x = new Pessoa();
      Pessoa y = new Pessoa();

      Console.WriteLine("Entre com o nome e idade:");
      x.NomeC = (Console.ReadLine());
      x.IdadeA = int.Parse(Console.ReadLine());

      Console.WriteLine("Entre com o nome e idade:");
      y.NomeD = (Console.ReadLine());
      y.IdadeB = int.Parse(Console.ReadLine());

      if(x.IdadeA > y.IdadeB){
          Console.WriteLine("{0} é mais velha que {1}", x.NomeC, y.NomeD);
        }
        else{
            Console.WriteLine("{0} é mais velho que {1}", y.NomeD, x.NomeC);
        }
    
  }
}