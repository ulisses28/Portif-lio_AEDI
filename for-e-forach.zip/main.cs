using System;

class MainClass {
  public static void Main (string[] args) {
      int[] meuarray = new int[5];
      for( int i = 0;i < meuarray.Length; i++)
      {
          Console.WriteLine("digite um numero: ");
          meuarray[i] = Convert.ToInt32(Console.ReadLine());
      }
      Console.WriteLine();

      for(int i = 0; i < meuarray.Length; i++)
      {
          Console.WriteLine("posição {0}: {1}", i, meuarray[i]);
      }
    

      
  }
}