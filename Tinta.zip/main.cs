using System;
//Faça um Programa para uma loja de tintas. O programa deverá pedir o tamanho em metros quadrados da área a ser pintada. Considere que a cobertura da tinta é de 1 litro para cada 6 metros quadrados e que a tinta é vendida em latas de 18 litros, que custam R$ 80,00 ou em galões de 3,6 litros, que custam R$ 25,00.
//Informe ao usuário as quantidades de tinta a serem compradas e os respectivos preços em 3 situações:
//comprar apenas latas de 18 litros;
//comprar apenas galões de 3,6 litros;
//misturar latas e galões, de forma que o preço seja o menor. Acrescente 10% de folga e sempre arredonde os valores para cima, isto é, considere latas cheias.
class MainClass {
  public static void Main (string[] args) {
      
      Console.WriteLine("================================");
      Console.WriteLine("     Bem vindo a Politintas     ");
      Console.WriteLine("================================");
      Console.WriteLine("=====Lata 18litros = R$ 80,00===");
      Console.WriteLine("===Lata 3,6litros = R$ 25,00====");
      Console.WriteLine("Qual o tamanho das paredes: ");
      double A = double.Parse(Console.ReadLine());
      double B = double.Parse(Console.ReadLine());

      double Tamanho = (A * B)/2;
      double TotalLitros = Tamanho/6;

      Console.WriteLine("O tamanho de sua parede é: "+ Tamanho);
      Console.WriteLine("Você precisará de {0} litros de tinta", TotalLitros);
      
      string Litros1 ;
      double Litros2 ;
      Console.WriteLine("Litros1 ou Litros2");
      Console.WriteLine("Quantos litros de {0} deseja comprar? ", Litros1);
      string qtdLitro1 = Console.ReadLine();
      string qtdLitro2 = Console.ReadLine();
      
      if(qtdLitro1 == Litros1 & qtdLitro2 == Litros1){
          TotalLitros  = TotalLitros/18;
          Console.WriteLine("Total litros necessarios "+ TotalLitros);
          double valorP =  TotalLitros * 80.00;
          Console.WriteLine("valor a pagar: "+ valorP);
          
        }
        double valorS;
        else{
            if(qtdLitro1 == Litros2 & qtdLitro2 == Litros2){
            TotalLitros = TotalLitros/3.6;
            Console.WriteLine("Total litros necessarios "+ TotalLitros);
            valorS = TotalLitros * 25.00;
            Console.WriteLine("valor a pagar: "+ valorS);
            }
        } 
        double Desconto;
        else{
            double f = TotalLitros/(18.00 + 3.6);
            double valorB = f *(25.00 + 80.00);
            Console.WriteLine("valor a Bruto a pagar"+ valorB);
            Desconto = (valorB * 0.10) - valorB;
            Console.WriteLine(" valor com desconto: "+ Desconto);
        }
    }
}