#emprestimo bancario
salario = 0
ano = 12
vl_casa = 1
pagto = 1
mensalidade = salario*0.3 

vl_casa = int(input('qual é o valor da casa que voceê deseja comprar? '))
salario = float(input('qual é seu salario? '))
pagto = int(input('em quantos anos deseja pagar? '))

if mensalidade == salario*0.3:
  pagto = pagto*ano
  mensalidade = mensalidade*pagto
elif pagto *mensalidade < vl_casa:
  pagto = pagto*ano

  mensalidade = mensalidade*pagto
else:
  print('seu crédito não foi aprovado! ')
print('')
