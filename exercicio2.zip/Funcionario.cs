using System;

class Funcionario{
    public string Colaborador1;
    public float Salario1;
    public string Colaborador2;
    public float Salario2;

    public void Colaborador1(string f1){
        Colaborador1 = f1;
    }
    public void Salario1(float S1){
        Salario1 = S1;
    }
    public void Colaborador2(string f2){
        Colaborador2 = f2;
    }
    public void Salario2(float S2){
        Salario2 = S2;
    }
    public static CalculaMedia(){
        CalculaMedia = (Salario1 + Salario2)/2;
        return CalculaMedia;
    }
}