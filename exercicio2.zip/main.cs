using System;

class MainClass {
  public static void Main (string[] args) {
      Funcionario f1 = new Funcionario();
      Funcionario f2 = new Funcionario();

      Console.WriteLine("Nome do primeiro funcionario: ");
      f1.Colaborador1 = Console.ReadLine();
      Console.WriteLine("O salario de {0}"+ f1.Colaborador1)
      f1.Salario1 = float.Parse(Console.ReadLine());

      Console.WriteLine("Nome do primeiro funcionario");
      f2.Colaborador2 = Console.ReadLine();
      Console.WriteLine("O salario de {0}"+ f2.Colaborador2)
      f2.Salario2 = float.Parse(Console.ReadLine());
      
      Console.WriteLine ("{0} o seu salario é de {1}", f1.Colaborador1, f1.Salario1);
      Console.WriteLine ("{0} o seu salario é de {1}", f2.Colaborador2, f1.Salario2);
      Console.WriteLine("A media dos salario é"+ F.CauculaMedia())
  }
}