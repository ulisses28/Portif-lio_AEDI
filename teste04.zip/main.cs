using System;
  // Faça um Programa que pergunte quanto você ganha por hora e o número de horas trabalhadas no mês. Calcule e mostre o total do seu salário no referido mês, sabendo-se que são descontados 11% para o Imposto de Renda, 8% para o INSS e 5% para o sindicato, faça um programa que nos dê:
  //salário bruto.
//quanto pagou ao INSS.
//quanto pagou ao sindicato.
//o salário líquido.
//calcule os descontos e o salário líquido, conforme a tabela abaixo:
//+ Salário Bruto : R$
//- IR (11%) : R$
//- INSS (8%) : R$
//- Sindicato ( 5%) : R$
//= Salário Liquido : R$
  class MainClass{
      public static void Main (string[] args) {

      Console.WriteLine("Qual é o seu salário Bruto: ");
      double SalarioBruto = double.Parse(Console.ReadLine());

      double ThorasMes = 220.00;
      double ValorHOraDia = SalarioBruto/ThorasMes;
      double Adiantamento = SalarioBruto * 0.4;
      double IR = SalarioBruto * 0.11;
      double INSS = SalarioBruto * 0.08;
      double Sindicato = SalarioBruto * 0.05;
      double SalarioLiquido = SalarioBruto -(IR+INSS+Sindicato+Adiantamento);

      Console.WriteLine("O valor da hora dia é "+ ValorHOraDia);
      Console.WriteLine("Adiantamento: "+ Adiantamento);
      Console.WriteLine("Imposto de renda: "+ IR);
      Console.WriteLine("Desconto do INSS: "+ INSS);
      Console.WriteLine("Desconto Sindicato: "+ Sindicato);
      Console.WriteLine("salário liquido a receber é: "+ SalarioLiquido);

    }       
}