%Esta fun��o � capaz de reconhecer e nomear figuras especificas como 
%retangulos,estrelas, elipses, circulos e triangulos.

function classificador = Classificador(imagem)

%Esta linha de codigo recebe uma imagem
im=imread(imagem); 

%Imbinarize cria uma imagem binaria, escolhe o valor limite para minimizar
%a varia��o intraclasse dos pixels preto e branco com limite
img=imbinarize(im,0.3);

%Mostra a imagem.
imshow(img);


[img numberOfObjcts] = bwlabel(img);

%Regionprops mapeia e retorna medidas para o conjunto de propriedades especificado.
blobMeasurements = regionprops(img,'Perimeter','Area', 'Centroid'); 

%Circularidade refee-se a raz�o entre a �rea de sobreposi��o do objecto ao c�rculo equivalente e
%a �rea total do objecto, atrav�s de uma formula matematica esta
%identificando medidas do obejto.
circularities = [blobMeasurements.Perimeter].^2 ./ (4 * pi * [blobMeasurements.Area])
hold on;

%Este la�o de repeti��o identifica e nomeia a figura geom�trica de acordo
%com suas medidas e forma.
for blobNumber = 1 : numberOfObjcts    
  if circularities(blobNumber) < 2.1016
    message = sprintf('O objeto � uma estrela',...
    blobNumber, circularities(blobNumber));
    theLabel = 'Estrela';
  end
  if circularities(blobNumber) < 1.6243
      message = sprintf('O objeto � um Triangulo',...
      blobNumber, circularities(blobNumber));
    theLabel = 'Triangulo';      
  end
  if circularities(blobNumber) <1.4095
     message = sprintf('O objeto � um Retangulo',...
     blobNumber, circularities(blobNumber));
     theLabel = 'Retangulo';
  end 
  if circularities(blobNumber) <1.2264
    message = sprintf('O objeto � uma Elipse',...
      blobNumber, circularities(blobNumber));
    theLabel = 'Elipse';  
  end 
  if circularities(blobNumber) <0.9875
     message = sprintf('O objeto � um Circulo',...
     blobNumber, circularities(blobNumber));
     theLabel = 'Circulo';
  end
end  

  text(blobMeasurements(blobNumber).Centroid(1), blobMeasurements(blobNumber).Centroid(2),...
    theLabel, 'Color', 'r');
  uiwait(msgbox(message));
end


